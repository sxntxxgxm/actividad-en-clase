<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bootstrap demo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <div class="container text-center">
    <div class="row">
      <div class="col">
      <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">ProjectMaker</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Ejemplos</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Recursos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Plantillas</a></li>
            <li><a class="dropdown-item" href="#">Ejemplos</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Ayuda</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true"></a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me" type="search" placeholder="" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Buscar</button>
      </form>
    </div>
  </div>
</nav>
      </div>
      <div class="col">
      <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    Versión
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">V 1.0.1</a></li>
    <li><a class="dropdown-item" href="#">V 1.1.0</a></li>
    <li><a class="dropdown-item" href="#">V 1.2.4</a></li>
  </ul>
</div>
      </div>
    </div>
    <div class="row">
      <div class="col">
      <ul class="nav flex-column">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Nuevo Proyecto</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Cargar Proyecto</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Eliminar Proyecto</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" aria-disabled="true"></a>
  </li>
</ul>
      </div>
      <div class="col-5">
      <h6>Registro de Proyectos</h6>
      <form>
      <div class="mb-3">
  <label for="formGroupExampleInput" class="form-label"></label>
  <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del Proyecto">
</div>
<div class="form-floating">
  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
  <label for="floatingTextarea2">Descripción</label>
  <br>
</div>
  <div class="col-12">
    <button class="btn btn-primary" type="submit">Submit</button>
  </div>
  <button type="submit" class="btn mt-3 btn-primary">Guardar cambios</button>
</form>
      </form>
      </div>
      <div class="col">
      <ul class="nav flex-column">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Enlaces</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Referencias</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">About us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" aria-disabled="true"></a>
  </li>
</ul>
      </div>
    </div>
  </div>
</body>
</html>

<html>
    <body>
        <h1>Hello</h1>

        <?php $__currentLoopData = $pruebav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($proyecto->nombre); ?></li>
            <a href="<?php echo e(route('proyecto.edit', $producto ->id)); ?>">Editar</a>
            <a href="<?php echo e(route)'proyecto.edit', ['proyecto' => $proyecto])); ?>">Editar</a>
            <a href="<?php echo e(route('proyecto.update', $producto ->id)); ?>">Editar</a>
            <a href="<?php echo e(route)'proyecto.update', ['proyecto' => $proyecto])); ?>">Editar</a>
            <a href="<?php echo e(route('proyecto.destroy', $producto ->id)); ?>">Editar</a>
            <a href="<?php echo e(route)'proyecto.destroy', ['proyecto' => $proyecto])); ?>">Editar</a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html><?php /**PATH C:\wamp64\www\prueba\resources\views/proyecto/index.blade.php ENDPATH**/ ?>
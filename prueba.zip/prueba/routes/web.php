<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProyectosController;


Route::get('/', function () {
    return view('welcome');
});

Route::resource('proyecto', ProyectosController::class);

Route::put('/proyecto/{id}', 'ProyectosController@update')->name('proyecto.update');

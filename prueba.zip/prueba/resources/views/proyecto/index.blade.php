<html>
    <body>
        <h1>Hello</h1>

        @foreach ($pruebav as $proyecto)
            <li>{{$proyecto->nombre}}</li>
            <a href="{{ route('proyecto.edit', $proyecto ->id)}}">Editar</a>
            <a href="{{ route('proyecto.edit', ['proyecto' => $proyecto]) }}">Editar</a>
            <a href="{{ route('proyecto.update', $proyecto ->id)}}">Editar</a>
            <a href="{{ route('proyecto.update', ['proyecto' => $proyecto]) }}">Editar</a>
            <a href="{{ route('proyecto.destroy', $proyecto ->id)}}">Editar</a>
            <a href="{{ route('proyecto.destroy', ['proyecto' => $proyecto]) }}">Editar</a>
        @endforeach
    </body>
</html>
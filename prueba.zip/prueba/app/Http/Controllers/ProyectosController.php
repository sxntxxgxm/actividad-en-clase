<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Modelopbs;
use Illuminate\Support\Facades\DB;

class ProyectosController extends Controller
{
    public function index(){
        $prueba= DB::table('modelpbs')->get();
        return view('proyecto.index',['pruebav'=>$prueba]);
    }
    public function create()
    {
        return view('proyecto.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|max:255',
            'descripcion' => 'required',
        ]);
        Proyecto::create($request->all());
        return redirect()->route('proyecto.create')
            ->with('success','Post created succesfully.');
    }
    public function edit($id)
    {
        $producto = Proyecto::find($id);
        return view('proyecto.edit', compact('proyecto'));
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|max:255',
            'descripcion' => 'required',
        ]);
        $proyecto = Proyecto::find($id);
        $proyecto->update($request->all());
        return redirect()->route('proyecto.index')
                        ->with('success','Post updated successfully');
    }
    public function destroy($id)
    {
        $proyecto = Proyecto::find($id);
        $proyecto->delete();
        return redirect()->route('proyecto.index')
        ->with('success','Product deleted successfully');
    }
}